# Perix Mobility V14 — atomic out-of-order realtime protection

**Date:** 18 October 2026  
**Release status:** **STAGING CANDIDATE — NOT APPROVED FOR PRODUCTION**

V14 is the **cumulative V2–V14 bundle**. It supersedes all prior ZIP bundles. **Do not apply V12/V13 separately.** Nothing has been written to GitHub, Railway, production MongoDB, or the user's source ZIP. The normal installer modifies local files only when run with `--apply` on a clean **non-main/master feature branch**.

## Why V14 exists

V12 fixed the collision with the existing MongoDB unique index `(region_id, network_id, trip_id)`, but its `UpdateOne(key, {"$set": doc}, upsert=True)` could overwrite a newer realtime row with an older feed snapshot. V13 identified and documented this risk; it did not change the worker.

V14 **proposes** an atomic MongoDB aggregation-pipeline update guarded by the stored data:

- An incoming GTFS-Realtime TripUpdate must have a valid *source* feed timestamp (never replace it with the local fetch time). Missing/invalid, pre-activation and implausibly future timestamps are rejected.
- Within the same service day and activated network version, only a strictly newer source-feed timestamp may change the stored row. Equal timestamps are stable no-ops.
- When service date rolls forward, the new service day may replace the old day. An older day may not overwrite a newer day.
- For a same-day version change, a **known later activation time** can supersede the older version. For legacy V12 rows without activation metadata, crossover is permitted only when the old feed timestamp is demonstrably before the new activation. Ambiguous cases intentionally keep the old row (which the version-scoped reader does not expose) rather than fabricate realtime.
- The update *filter* stays **exactly** `(region_id, network_id, trip_id)`: version/date do **not** belong in the upsert filter because the unique index does not contain them.
- The conditional replacement occurs **inside the MongoDB update pipeline** (`$replaceRoot`, `$cond`, `$mergeObjects`, `$literal`), not an unsafe client-side read/compare/write.
- Concurrent new-row upserts that collide with the existing unique key get a bounded **update-only retry** using the same monotonic condition. Other errors propagate. This error path requires actual MongoDB testing.
- Duplicate TripUpdates in a single feed are deterministically deduplicated. Metrics distinguish `matched` from actual `stored` and count `clock_rejected`.

The MongoDB aggregation update needs MongoDB **4.2 or later** and appropriate driver support. **This candidate has not yet been run against an actual MongoDB server.** The offline expression interpreter tests the intended logic, *not server/operator support or concurrency guarantees*. This is a deliberately visible release blocker.

V14 makes no network- or MVB-specific assumptions; location/operator handling remains configured per network as in V8.

## Files specific to V14

- `perix_apply_mobility_v14.py` — new cumulative installer entrypoint. It composes all V12 changes and adds `backend/mobility/realtime_order.py` plus an updated realtime worker.
- `perix_v14_realtime_order_core.py` — source for the new backend module with validation and atomic update pipeline.
- `test_perix_v14_realtime_order.py` and `test_perix_v14_patch_safety.py` — deterministic, dependency-free tests.
- `perix_v14_source_contract_audit.py` — read-only static check for the intended index, reader and writer contracts.
- `perix_v14_mongo_staging_concurrency.py` — **opt-in staging-only** isolated collection write test. It does nothing unless specifically enabled.
- `perix_v14_verify_checkout.py` — uses a full clean local Git checkout, verifies 13 observed baseline blobs, creates a disposable clone, and applies/tests inside that clone. Inherited source baseline from V10.
- `PERIX_V14_REAL_CHECKOUT_AUDIT.md` — evidence and blockers.

## Tests performed on the actual Perix source archive (2026-10-18)

| Check | Outcome |
|---|---|
| Standalone ZIP offline tests, including V14 | **159/159 PASS** (plus 10 subtests) |
| Selected original Perix DB-free Mobility tests | **146/146 PASS** |
| Cumulative `--check` | **PASS — 46 composed targets** |
| `--apply` on fresh local throwaway feature branch | **PASS — 46 local targets** |
| Git diff `--check` and Python `compileall` | **PASS** |
| V14 static/source contract | **PASS, source-only** |
| Actual MongoDB driver/server concurrent pipeline test | **BLOCKED — `pymongo`, `motor`, and staging Mongo access unavailable here** |
| Full backend suite with `motor` | **BLOCKED** |
| Locked frontend npm `typecheck` and lint | **BLOCKED / NOT RUN** — dependencies unavailable |
| Same-time Google Maps / observed arrival ETA benchmark | **NOT RUN** |

**Never interpret the synthetic interpreter or the staging test in dry mode as a real MongoDB integration test.** The current V13 source audit deliberately labels any pipeline update `BLOCKED` until verified; use the V14 contract audit to check expected code structure but do not interpret its PASS as production approval.

## Run checks locally — no files changed in your Perix checkout

Extract this V14 ZIP into a directory **outside** the original Git checkout:

```bash
python3 perix_v9_offline_tests.py
python3 perix_apply_mobility_v14.py /path/to/Perix --check
python3 perix_v14_verify_checkout.py /path/to/Perix \
  --out /tmp/perix-v14-verifier-results \
  --full-backend --install-frontend-deps
```

The verifier demands a clean real Git checkout. It clones that checkout to a temporary directory and runs `--apply` **only inside the clone**. `--install-frontend-deps` attempts `npm ci` only inside that clone and may require a network connection. If the original source differs from the observed 13 Git blob IDs, it **stops** until the newer source is reviewed.

**Do not run `--apply` on main/master, a production checkout, or Railway.** If preparing a local review branch later, use the normal installer there only after reviewing the exact changes. No deployment should occur before completing the remaining gates.

## Staging-only Mongo concurrency test (NOT executed here)

This deliberately requires **write privileges to a dedicated staging MongoDB** and will create/drop a temporary collection inside `perix_v14_staging_validation`. It cannot establish whether a URI secretly points at a production cluster: **the operator must verify the isolated staging hostname/account and credentials**. It never accesses `mobility_realtime` or application collections. No URL or credential is printed.

```bash
# Supply securely in your STAGING environment only, never paste credentials here:
# PERIX_V14_STAGING_MONGO_URI=<staging write credential>
python3 perix_v14_mongo_staging_concurrency.py --environment staging --write-staging-test
```

Without `--write-staging-test` or a dedicated `PERIX_V14_STAGING_MONGO_URI`, the script exits **BLOCKED** without opening a connection. Requires Python `pymongo` installed in staging. The test checks a legacy unique index, 100 overlapping writes, network version order and final timestamp; it cleans up its temporary test collection even on failure, as long as cleanup succeeds. **It is not a substitute for testing the full async worker, bulk-write error handling, real GTFS replay or index migration/readiness.**

## Mandatory production release gates

1. Confirm the **actual staging Mongo indexes, server version, and `motor`/`pymongo` driver**; run the V13 read-only audit and V14 *staging-only* concurrency test; exercise concurrent async `bulk_write`/duplicate-key retry with real workers and service-day transitions.
2. Run **all** backend tests with their real dependencies against an isolated staging/test DB. Do not accept only the DB-free subset.
3. Run `npm ci`, TypeScript typecheck, and frontend lint using the committed lockfile, with fixes if tests fail.
4. Verify approved official detour/temporary-line IDs against the actual operator feeds. Keep operator labels opt-in.
5. Compare contemporaneous Perix, provider, Google Maps, and observed-arrival samples before claiming any numeric ETA accuracy.
6. Conduct a reviewed staging rollout with logs, a rollback plan, and only then consider a production release.

**Release verdict: V14_LOCAL_TESTS_PASS / MONGODB_STAGING_AND_FULL_INTEGRATION_REQUIRED.**
